import json
import urllib.parse
import boto3
import os

print('Loading function')

s3 = boto3.client('s3')
sage_client = boto3.client('runtime.sagemaker')    
sqs = boto3.client('sqs')
queue_url = os.environ['QUEUE_URL']

def lambda_handler(event, context):

    try:
        sqs_messages = sqs.receive_message(
            QueueUrl=queue_url,
            AttributeNames=['ReceiptHandle','Body'],
            MaxNumberOfMessages=2
        )
        print("SQS messages retrived: ", sqs_messages)

        sqs_messages = sqs_messages["Messages"]
        
        message_to_delete = sqs_messages[0]
        
        print('Message to delete: ',message_to_delete)
        sqs.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=message_to_delete["ReceiptHandle"]
        )
        if len(sqs_messages) > 1:
            message_to_process = sqs_messages[1]
            message_to_process = json.loads(message_to_process["Body"])
            print('message_to_process',message_to_process)
            response = sage_client.invoke_endpoint_async(
                EndpointName=message_to_process["endpoint_name"], 
                InputLocation=message_to_process["input_s3_location"]
            )
            output_location = response["OutputLocation"]
            return output_location
        
        return "Done without new processing"
    except Exception as e:
        print(e)
        raise e
