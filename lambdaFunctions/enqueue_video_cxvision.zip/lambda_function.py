import json
import urllib.parse
import boto3
import uuid
import os
from build_payload import *

print('Loading function')

s3 = boto3.client('s3')
sage_client = boto3.client('runtime.sagemaker')
sqs = boto3.client('sqs')

out_bucket = os.environ['OUT_BUCKET']
prefix = os.environ['S3_INPUT_DATA_ENDPOINT_DIR']
queue_url = os.environ['QUEUE_URL']
endpoint_name = os.environ['ENDPOINT_NAME']

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    video_name = key.split('/')[-1].rsplit('.',1)[0]
    
    if (video_name == ''):
        return
    
    try:
        print('New video detected at ', 's3://' + bucket + '/' + key)

        payload = build_payload(bucket, key, video_name)      
        new_file = '{}-{}.json'.format(str(uuid.uuid4()), video_name)
        input_s3_location = 's3://' + out_bucket + '/' + prefix + new_file
        
        boto3.resource('s3').Bucket(out_bucket).put_object(
            Body=json.dumps(payload, indent=2),
            ContentType='application/json',
            Key=prefix + new_file
        )
        
        sqs_message = {"endpoint_name": endpoint_name, "input_s3_location": input_s3_location}
        
        sqs.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(sqs_message),
            MessageGroupId=bucket
        )
        
        queue_messages_quantity = sqs.get_queue_attributes(
            QueueUrl=queue_url,
            AttributeNames=['ApproximateNumberOfMessages']
        )
        queue_messages_quantity = queue_messages_quantity["Attributes"]["ApproximateNumberOfMessages"]
        
        print("Messages in queue: ", queue_messages_quantity)

        if int(queue_messages_quantity) == 1:
            print("First video invoked")
        
            response = sage_client.invoke_endpoint_async(
                EndpointName=endpoint_name, 
                InputLocation=input_s3_location
            )
            output_location = response["OutputLocation"]
            print(f"OutputLocation: {output_location}")
            
            return output_location
            
        return "Done"
    except Exception as e:
        print(e)
        raise e
