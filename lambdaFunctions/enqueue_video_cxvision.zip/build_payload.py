import os
import json

def build_payload(bucket, key, video_name):
    f = open('payload.json')
    payload = json.load(f)
        
    area = video_name.split("area_")
    if len(area) > 1:
        area = area[-1].split("_")[0]
    else:
        area = "default"

    payload["blurring"] = True if (os.environ.get('BLURRING', "False")).lower() == "true" else False
    payload["detection_threshold"] = int(os.environ.get('DETECTION_THRESHOLD', payload["detection_threshold"]))
    payload["refresh_threshold"] = int(os.environ.get('REFRESH_THRESHOLD', payload["refresh_threshold"]))
    payload["timezone"] = os.environ.get('TIMEZONE', payload["timezone"])
    payload["s3_upload_path"] = os.environ.get('S3_UPLOAD_RESULTS_DIR', payload["s3_upload_path"])
    payload["areas"] = json.loads(os.environ.get("AREAS", json.dumps(payload["areas"])))
    payload["videos"].append({'path': 's3://' + bucket + '/' + key, 'area': area})

    return payload